Doubly linked lists.
