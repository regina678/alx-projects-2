0x12-singly_linked_lists.
