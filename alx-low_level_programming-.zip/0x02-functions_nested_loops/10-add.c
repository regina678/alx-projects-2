#include "main.h"

/**
 * add - add two numbers from input
 * @a: first aparamet
 * @b: second parameter
 *
 * Description: adds two numbers
 * Return: Always (0).
 */
int add(int a, int b)
{
return (a + b);
}
