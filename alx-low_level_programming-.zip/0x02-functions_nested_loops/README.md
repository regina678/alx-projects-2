program that prints _putchar, followed by a new line.
function that prints the alphabet, in lowercase, followed by a new line.
function that prints 10 times the alphabet, in lowercase, followed by a new line.
function that checks for lowercase character.
function that checks for alphabetic character.
function that prints the sign of a number.
function that computes the absolute value of an integer.
function that prints the last digit of a number.
function that prints every minute of the day of Jack Bauer, starting from 00:00 to 23:59.
function that prints the 9 times table, starting with 0.
function that adds two integers and returns the result.
function that prints all natural numbers from n to 98, followed by a new line.
function that prints the n times table, starting with 0.
prints the sum of the even-valued terms, followed by a new line.
