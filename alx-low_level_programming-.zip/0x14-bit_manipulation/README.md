0x14. C - Bit manipulation
