Dynamic libraries.
